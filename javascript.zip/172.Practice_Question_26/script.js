let a = ["january", "july", "march", "august"];
a.shift();
a.shift();
a.unshift("june");
a.unshift("july");
console.log(a);
