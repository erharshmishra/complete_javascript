let months = ["january", "july", "march", "august"];
console.log(months.splice(0, 2, "july", "june"));
console.log(months);
