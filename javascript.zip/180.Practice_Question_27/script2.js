let languages = [
  "c",
  "c++",
  "html",
  "javascript",
  "python",
  "java",
  "c#",
  "sql",
];
console.log(languages.indexOf("javascript"));
console.log(languages.reverse().indexOf("javascript"));
