console.log("Before if block.");
let age = 14;
if (age >= 18) {
  console.log("You can vote.");
} else {
  console.log("You cannot vote.");
}
console.log("After if block.");
