console.log("Before if block.");
let age = 22;
if (age >= 18) {
  console.log("You can vote.");
}
console.log("After if block.");
