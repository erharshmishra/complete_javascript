function poem() {
  console.log(
    "Johny, Johny\nYes, Papa?\nEating sugar?\nNo, Papa.\nTelling lies?\nNo, Papa.\nOpen your mouth.\nHa-ha-ha!"
  );
}
poem();
