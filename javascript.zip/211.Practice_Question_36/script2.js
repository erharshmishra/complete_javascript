function roll() {
  let dice = Math.floor(Math.random() * 6) + 1;
  console.log(dice);
}
roll();
