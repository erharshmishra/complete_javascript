let num = 5;
console.log(num);
let newNum = num++;
console.log(newNum);
console.log(num);
newNum = ++num;
console.log(newNum);
console.log(num);
