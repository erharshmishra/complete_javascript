// console.log("Hi,there!");
// setTimeout(function sum() {
//     console.log("Apna College.");
// }, 1000);
// console.log("Welcome to,");

// console.log("Hi,there!");
// setTimeout( sum = function() {
//     console.log("Apna College.");
// }, 1000);
// console.log("Welcome to,");

// console.log("Hi,there!");
// setTimeout( sum = () => {
//     console.log("Apna College.");
// }, 1000);
// console.log("Welcome to,");

console.log("Hi,there!");
setTimeout(() => {
  console.log("Apna College.");
}, 1000);
console.log("Welcome to,");
