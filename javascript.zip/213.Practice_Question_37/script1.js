function calAverage(num1, num2, num3) {
  console.log(
    `Average of ${num1}, ${num2} and ${num3} is ${(num1 + num2 + num3) / 3}`
  );
}
calAverage(2, 7, 2);
