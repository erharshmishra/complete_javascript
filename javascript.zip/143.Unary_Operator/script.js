let a = 10;
let b = 5;
console.log(a++);
console.log(++a);
console.log(b--);
console.log(--b);
