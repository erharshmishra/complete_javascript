let a = 10;
let b = 20;
console.log(`Your pay is ${a + b} rupees`);
console.log("Price is", a + b, "rupees");
console.log("Price is " + (a + b) + " rupees");
