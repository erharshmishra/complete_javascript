let fruits = ["mango", "banana", "orange", "litchi", "apple"];

for (let fruit of fruits) {
  console.log(fruit);
}

for (let char of "apnacollege") {
  console.log(char);
}
