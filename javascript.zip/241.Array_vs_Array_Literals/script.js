// Array Literals '[]' indentity.

let arr = [1, 3, 4, 2];
console.log(arr);

// Array.

let arr1 = new Array(1, 2, 3, 4, 5);
console.log(arr1);
