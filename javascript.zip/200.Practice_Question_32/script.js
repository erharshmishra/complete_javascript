let post = {
  username: "@akaharsh",
  content: "I am bad boy.",
  likes: 200000,
  reposts: 1000,
  tags: ["@erharshmishra", "@apnacollege", "@akaharsh"],
};
console.log(post);
