let str = "Appleb";
if ((str[0] == "a" || str[0] == "A") && str.length > 5) {
  console.log("Golden");
} else {
  console.log("Not golden");
}
