let fullName, age;
fullName = prompt("Enter your fullname : ");
age = prompt("Enter your age : ");
alert(`${fullName} is ${age} years old`);
document.write(`${fullName} is ${age} years old`);
