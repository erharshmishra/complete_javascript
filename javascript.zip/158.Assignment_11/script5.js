let num1 = 21,
  num2 = 34,
  num3 = 12;
if (num1 > num2 && num1 > num3) {
  console.log(`${num1} is largest`);
} else if (num2 > num1 && num2 > num3) {
  console.log(`${num2} is largest`);
} else {
  console.log(`${num3} is largest`);
}
