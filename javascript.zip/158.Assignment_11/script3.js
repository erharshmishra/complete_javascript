let monthQuarter = 1;
switch (monthQuarter) {
  case 1:
    console.log("January,February,March");
    break;
  case 2:
    console.log("April,May,June");
    break;
  case 3:
    console.log("July,August,September");
    break;
  case 4:
    console.log("October,November,December");
    break;
  default:
    console.log("Wrong Number!");
}
