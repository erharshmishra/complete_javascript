let num1 = 12,
  num2 = 32432;
if (num1 % 10 == num2 % 10) {
  console.log(`${num1} and ${num2} both have same last digit`);
} else {
  console.log(`${num1} and ${num2} both have not same last digit`);
}
