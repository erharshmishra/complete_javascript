let num = 210;
if (num % 10 == 0) {
  console.log("Good");
} else {
  console.log("Bad");
}
