let person = {
  name: "Harsh",
  age: 21,
  city: "Gorakhpur",
};
console.log("Original Data : ", person);
person.city = "New York";
person.country = "United States";
console.log("Updated Data : ", person);
