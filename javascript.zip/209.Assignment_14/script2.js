let car = {
  name: "BMW",
  model: 2025,
  color: "black",
};
console.log(car);
console.log(car.name);
