let random = Math.floor(Math.random() * 6) + 1;
console.log(random);
