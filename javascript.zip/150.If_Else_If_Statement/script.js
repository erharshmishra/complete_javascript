console.log("Before if block.");
let color = "green";
if (color == "red") {
  console.log("Stop");
} else if (color == "yellow") {
  console.log("Slow Down");
} else if (color == "green") {
  console.log("Go");
} else {
  console.log("Invalid color.");
}
console.log("After if block.");
