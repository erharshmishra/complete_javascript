setTimeout(function () {
  console.log("Harsh Mishra");
}, 2000);

console.log("Hello ,");
