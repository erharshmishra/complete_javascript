let num = [1, 2, 3, 4];

let double = num.map(function (el) {
  return el * 2;
});
console.log(double);
