let sum = (a, b) => {
  console.log(a + b);
};
sum(4, 3);

let cube = (n) => {
  // n is parameter.
  return n * n * n;
};
// 5 is argument.
console.log(cube(5));
