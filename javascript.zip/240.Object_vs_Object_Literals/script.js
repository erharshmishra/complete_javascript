// Object Literals '{}' identity.

let car = {
  model: "swift desire 2024 model",
  color: "black",
  type: "car",
};
console.log(car);

// Object.

let fruits = new Object();
fruits.fr1 = "mango";
fruits.fr2 = "orange";
fruits.fr3 = "banana";
fruits.fr4 = "pineapple";
console.log(fruits);
