let arr = ["array", "boy", "hello", "dog"];
let newArr = arr.map((word) => word.toUpperCase());
console.log(newArr);
