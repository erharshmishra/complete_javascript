let nums = [2, 3, 4, 5, 6];
let newNums = nums.map((num) => num + 5);
console.log(newNums);
