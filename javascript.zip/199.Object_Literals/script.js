const student = {
  fname: "Harsh",
  age: 21,
  marks: 82,
  rollno: 9,
};
console.log(student);
