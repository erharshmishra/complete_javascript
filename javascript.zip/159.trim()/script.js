let msg = "  hello  ";
let newMsg = msg.trim();
console.log(newMsg);
console.log(msg);
