function hello() {
  console.log("Hi, Harsh Mishra");
}
hello();
