let students = ["harsh", "rohan", "ayush"];
console.log(students);
console.log(students.length);
console.log(students[0][1]);
console.log(students[0].length);

let marks = [21, 34, 65, 96];
console.log(marks);

let mix = [21, 34, "harsh", 96, 3.5, "h"];
console.log(mix);

let empty = [];
console.log(empty);
