function printName(name, age) {
  console.log(`${name} is ${age} years old.`);
}
printName("Harsh", 21);
