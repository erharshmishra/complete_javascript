let arr = [1, 2, 3, 4];

let sum = arr.reduce((res, ele) => {
  return res + ele;
});
console.log(sum);
