let fruits = ["mango", "orange", "litchi"];
console.log(fruits);
fruits[0] = "banana";
console.log(fruits);
fruits[10] = "pineapple";
console.log(fruits);
console.log(fruits.length);
