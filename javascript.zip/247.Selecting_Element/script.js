// Select Elemnt by Id.
let a = document.getElementById("mainImg");
console.log(a);
// a.src = "assets/creation_1.png";

// Select Elemnt by Class Name.
let b = document.getElementsByClassName("oldImg");
console.log(b);
console.log(b[2]);

// const d = () => {
//     a.src = "assets/creation_1.png";
// }

// Select Elemnt by Tag Name.
let c = document.getElementsByTagName("p");
console.log(c);
console.dir(c);

// let e = document.getElementsByTagName("h1");
// console.log(e);
// e[0].innerText = "Harsh Mishra";
