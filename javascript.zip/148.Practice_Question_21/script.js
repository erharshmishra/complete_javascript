let color = "red";
if (color == "red") {
  console.log("Stop");
}
if (color == "yellow") {
  console.log("Slow Down");
}
if (color == "green") {
  console.log("Go");
}
