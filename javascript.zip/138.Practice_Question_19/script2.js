let marks = 75;
console.log(marks);
let isPass = true;
console.log(isPass);
