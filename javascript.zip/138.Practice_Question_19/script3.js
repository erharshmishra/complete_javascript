let isPass = "true";
console.log(isPass);
