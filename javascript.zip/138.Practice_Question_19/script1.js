let age1 = 10;
console.log(age1);
let age2 = 20;
console.log(age2);
