let name = "ApnaCollege";
console.log(name.slice(4).replaceAll("l", "t"));
