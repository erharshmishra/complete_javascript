let Name = "ApnaCollege";
console.log(Name.slice(4, 9));
console.log(Name.indexOf("na"));
console.log(Name.replace("Apna", "Our"));
