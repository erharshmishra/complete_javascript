let msg = "help!";
console.log(msg.trim().toUpperCase());
