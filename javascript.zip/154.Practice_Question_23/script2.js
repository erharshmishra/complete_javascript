let num = 12;
if (num % 3 == 0 && (num + 1 == 15 || num - 1 == 11)) {
  console.log("Safe");
} else {
  console.log("Unsafe");
}
