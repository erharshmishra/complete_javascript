let str = "apple";
if (str[0] == "a" && str.length > 3) {
  console.log("Good String");
} else {
  console.log("Not a good string");
}
