let movies = [
  ["spiderman", "superman", "thor"],
  ["ironman", "wonder woman", "flash"],
];

for (let list of movies) {
  for (let movie of list) {
    console.log(movie);
  }
}
