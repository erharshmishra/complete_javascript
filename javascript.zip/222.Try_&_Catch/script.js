console.log("hello1");
console.log("hello1");

try {
  console.log(a);
} catch {
  console.log("variable a is not defined");
} finally {
  console.log("all the best");
}

console.log("hello2");
console.log("hello2");
console.log("hello2");
