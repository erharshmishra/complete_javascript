let size = "M";
if (size == "XL") {
  console.log("Price is RS. 250");
} else if (size == "L") {
  console.log("Price is RS. 200");
} else if (size == "M") {
  console.log("Price is RS. 100");
} else if (size == "S") {
  console.log("Price is RS. 50");
} else {
  console.log("No other options are available.");
}
