const cube = (n) => n * n * n;
console.log(cube(4));

const mul = (a, b) => a * b;
console.log(mul(4, 3));

const square = (n) => n * n;
console.log(square(4));
