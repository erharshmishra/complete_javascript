let cars = ["bmw", "audi", "toyota"];
console.log(cars);
cars.push("maruti", "fortuner");
console.log(cars);
