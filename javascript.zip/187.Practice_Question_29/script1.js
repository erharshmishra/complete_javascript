for (i = 1; i <= 15; i = i + 2) {
  console.log(i);
}
