let arr = [2, 3, 5, 6, 8, 9];

let trueOrFalse = arr.some((ele) => {
  return ele % 2 == 0;
});
console.log(trueOrFalse);

let array = [2, 4, 6];

let newtrueOrFalse = array.some((ele) => {
  return ele % 2 == 0;
});
console.log(newtrueOrFalse);

let ar = [1, 3, 5];

let newar = ar.some((ele) => {
  return ele % 2 == 0;
});
console.log(newar);
