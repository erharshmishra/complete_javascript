let marks = 35;
if (marks >= 33 && marks <= 100) {
  console.log("Pass");
}
if (marks >= 0 || marks <= 100) {
  console.log("Fail");
}
if (!(marks >= 36)) {
  console.log("Fail");
}
