let str = "Hello";
console.log(str.toUpperCase());
console.log(str.toLowerCase());
