let cars = ["bmw", "audi", "toyota"];
console.log(cars);
cars.shift();
console.log(cars);
cars.shift();
console.log(cars);
