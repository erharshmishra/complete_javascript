let primary = ["orange", "blue", "green"];
console.log(primary.includes("orange"));
console.log(primary.includes("red"));
