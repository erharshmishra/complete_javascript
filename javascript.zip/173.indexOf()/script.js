let primary = ["red", "yellow", "pink", "orange"];
console.log(primary.indexOf("yellow"));
console.log(primary.indexOf("Yellow"));
console.log(primary.indexOf("orange"));
