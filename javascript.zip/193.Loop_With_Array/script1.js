let fruits = ["Mango", "Apple", "Pineapple", "Orange", "Litchi"];

for (let i = 0; i < fruits.length; i++) {
  console.log(i, fruits[i]);
}
