let fruits = ["Mango", "Apple", "Pineapple", "Orange", "Litchi"];

for (let i = fruits.length - 1; i >= 0; i--) {
  console.log(i, fruits[i]);
}
