let str = "apnacollege" + 123;
console.log(str);
