let firstName = "Harsh";
console.log(firstName[0]);
