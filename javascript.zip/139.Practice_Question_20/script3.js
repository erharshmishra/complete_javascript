let firstName = "Harsh";
console.log(firstName[firstName.length - 1]);
