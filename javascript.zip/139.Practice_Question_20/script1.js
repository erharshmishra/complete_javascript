let fullName = "Harsh Mishra";
console.log(fullName);
console.log(fullName.length);
console.log(typeof fullName);
