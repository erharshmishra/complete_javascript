let a = "";
console.log(a.length);
let b = " ";
console.log(b.length);
