const checkerNumber = (n) => {
  if (n % 2 == 0) {
    return "even";
  } else {
    return "odd";
  }
};
console.log(checkerNumber(10));
