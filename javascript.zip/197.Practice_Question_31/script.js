let todo = [];
let req = prompt("please enter your request.");

while (true) {
  if (req == "quit") {
    console.log("Quitting the app.");
    break;
  }
  if (req == "list") {
    console.log("----------");
    for (let i = 0; i < todo.length; i++) {
      console.log(i, todo[i]);
    }
    console.log("----------");
    req = prompt("Enter your request.");
  } else if (req == "add") {
    let task = prompt("please enter your task.");
    todo.push(task);
    console.log("Task Added Succussfully..");
    req = prompt("Enter your request.");
  } else if (req == "delete") {
    let idx = prompt("please enter task index.");
    todo.splice(idx, 1);
    console.log("Task Deleted Succussfully..");
    req = prompt("Enter your request.");
  } else {
    console.log("Wrong Request.");
    req = prompt("Enter your request.");
  }
}
