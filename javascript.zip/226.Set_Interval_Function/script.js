setInterval(() => {
  console.log("Harsh Mishra");
}, 1000);

let id = setInterval(() => {
  console.log("Harsh");
}, 1000);

// Use to stop the execution.
clearInterval(id);
