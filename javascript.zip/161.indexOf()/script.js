let str = "ILoveCoding";
console.log(str.indexOf("Love"));
console.log(str.indexOf("J"));
console.log(str.indexOf("o"));
console.log(str.length);
console.log(str[0]);
console.log(str[str.length - 1]);
