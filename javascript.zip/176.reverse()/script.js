let primary = ["red", "yellow", "green"];
let secondary = ["orange", "pink", "blue"];
console.log(primary.reverse());
console.log(secondary.reverse());
