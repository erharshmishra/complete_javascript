let random = Math.floor(Math.random() * 5) + 21;
console.log(random);
