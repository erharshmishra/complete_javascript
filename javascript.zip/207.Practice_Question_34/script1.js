let random = Math.floor(Math.random() * 100) + 1;
console.log(random);
