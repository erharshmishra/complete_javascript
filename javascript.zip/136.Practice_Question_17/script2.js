let hindi = 80;
let eng = 90;
let math = 100;
let avg;
avg = (hindi + eng + math) / 3;
console.log(avg);
