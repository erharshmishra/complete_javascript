let age = 23;
age = age + 2;
console.log(age);
