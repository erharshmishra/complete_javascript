let colors = ["red", "yellow", "orange", "blue", "green"];
console.log(colors.sort());
let marks = [24, 100, 99, 29, 20, 49];
console.log(marks.sort());
