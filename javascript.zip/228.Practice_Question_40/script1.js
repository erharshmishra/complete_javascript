const sqr = (n) => n * n;
console.log(sqr(8));
