let str = "ILoveCoding";
console.log(str.replace("Love", "do"));
console.log(str.replace("ove", ""));
console.log(str.replace("o", "x"));

let msg = "Mishra ";
console.log(msg.repeat(2));
