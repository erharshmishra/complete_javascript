let arr = [1, 2, 3, 2, 6, 4, 9, 8];
console.log(arr);
console.log(...arr);
console.log(..."apnacollege");
console.log(Math.min(...arr));
console.log(Math.max(...arr));
