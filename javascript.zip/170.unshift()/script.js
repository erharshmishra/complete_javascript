let cars = ["bmw", "audi", "toyota"];
console.log(cars);
cars.unshift("maruti");
console.log(cars);
cars.unshift("alto", "auto");
console.log(cars);
