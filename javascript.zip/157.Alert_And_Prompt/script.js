let firstName, lastName, fullName;
firstName = prompt("Enter your first name : ");
lastName = prompt("Enter your last name : ");
fullName = `Welcome ${firstName} ${lastName}!`;
alert(fullName);
confirm("Can we print your name on display");
console.log(fullName);
