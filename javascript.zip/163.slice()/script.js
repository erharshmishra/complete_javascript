let str = "ILoveCoding";
console.log(str.slice(5));
console.log(str.slice(1, 4));
console.log(str.slice(-6));
console.log(str.slice(11 - 6));
console.log(str.slice(-2));
