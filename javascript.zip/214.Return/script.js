function sum(a, b) {
  return a + b;
}

let s = sum(3, 4);
console.log(s);
