let obj = {
  name: "harsh",
  roll: 9,
  class: "btech",
};

let objCopy = { ...obj, id: 1 };
console.log(objCopy);
