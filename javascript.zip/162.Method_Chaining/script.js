let str = "  Hello World  ";
let newStr = str.toUpperCase().trim();
console.log(newStr);
