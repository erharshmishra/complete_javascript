let num = [10, 11, 23, 34, 40];

let arr = num.every((ele) => ele % 10 == 0);
console.log(arr);

let againNum = [10, 60, 70, 230, 40];

let againArr = againNum.every((ele) => ele % 10 == 0);
console.log(againArr);
