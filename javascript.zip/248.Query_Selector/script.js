// Select Element by Query Selector.

console.log(document.querySelector("p"));
console.log(document.querySelector("#description"));
console.log(document.querySelector(".oldImg"));

// Select Element by Query Selector All.
console.log(document.querySelectorAll(".oldImg"));
console.log(document.querySelectorAll("p"));
console.log(document.querySelectorAll("a"));
console.log(document.querySelectorAll("div a"));
