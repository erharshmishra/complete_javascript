let str = "hello";
index = 3;
if (str[index] == str[index].toLowerCase()) {
  console.log("Character is in lowercase");
} else {
  console.log("Character is in uppercase");
}
