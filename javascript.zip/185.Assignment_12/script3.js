let str = "hello";
a = str.length;
if (a == 0) {
  console.log("String is blank.");
} else {
  console.log("String is not blank.");
}
