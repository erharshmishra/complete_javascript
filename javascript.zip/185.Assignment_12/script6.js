let arr = [12, 45, 68, 78, 99];
item = 6;
if (arr.indexOf(item) != -1) {
  console.log("Item is present in array");
} else {
  console.log("Item is not present in array");
}
