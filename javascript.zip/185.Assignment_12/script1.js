let arr = [1, 2, 3, 4, 5, 6];
let n = 3;
console.log(arr.slice(0, n));
