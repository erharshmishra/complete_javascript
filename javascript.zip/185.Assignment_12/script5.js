let str = "   harsh  ";
console.log(str);
console.log(str.trim());
