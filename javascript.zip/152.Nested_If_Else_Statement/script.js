let marks = 45;
if (marks >= 33) {
  console.log("Pass");
  if (marks >= 90) {
    console.log("Grade : O");
  } else {
    console.log("Grade : A");
  }
} else {
  console.log("Fail");
}
