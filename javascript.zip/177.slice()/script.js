let colors = ["red", "yellow", "orange", "blue", "green"];
console.log(colors.slice());
console.log(colors.slice(2));
console.log(colors.slice(-2));
console.log(colors.slice(2, 4));
console.log(colors.slice(2, colors.length));
