const classInfo = [
  {
    name: "Aman",
    grade: "A+",
    city: "Delhi",
  },
  {
    name: "Harsh",
    grade: "O",
    city: "Gorakhpur",
  },
  {
    name: "Karan",
    grade: "A",
    city: "Pune",
  },
];
console.log(classInfo);
console.log(classInfo[0].grade);
