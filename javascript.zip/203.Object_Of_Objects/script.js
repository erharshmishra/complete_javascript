const classInfo = {
  Aman: {
    grade: "A+",
    city: "Delhi",
  },
  Harsh: {
    grade: "O",
    city: "Gorakhpur",
  },
  Karan: {
    grade: "A",
    city: "Pune",
  },
};
console.log(classInfo);
